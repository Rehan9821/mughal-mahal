import React from 'react';
import { motion } from 'motion/react';
import { Calendar, Utensils, ChevronDown } from 'lucide-react';
import { restaurantInfo } from '../data/restaurantData.ts';
import { SignatureDishStory } from '../components/SignatureDishStory.tsx';
import { RestaurantExperienceStory } from '../components/RestaurantExperienceStory.tsx';
import { SignatureHighlights } from '../components/SignatureHighlights.tsx';
import { CompactReservationCTA } from '../components/CompactReservationCTA.tsx';

interface HomePageProps {
  navigate: (route: string) => void;
  onOpenReservation: () => void;
  onOpenOrder: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  navigate,
  onOpenReservation,
  onOpenOrder
}) => {
  const scrollToContent = () => {
    const el = document.getElementById('culinary-story');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div id="home-page" className="relative">
      {/* ====================================================
          1. CINEMATIC HERO (100svh)
      ==================================================== */}
      <section
        id="hero-section"
        className="relative h-[100svh] min-h-[640px] flex flex-col justify-between overflow-hidden bg-[#070709]"
      >
        {/* Atmosphere Background with Depth, Vignette, and Film Tone */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=2200&q=85"
            alt="Mughal Mahal Royal Dining Atmosphere"
            className="w-full h-full object-cover object-center scale-105 filter brightness-[0.28] contrast-[1.12] saturate-[0.85]"
          />
          {/* Radial depth vignette */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(0,0,0,0.2)_0%,#070709_92%)]" />
          {/* Subtle warm vertical gradient */}
          <div className="absolute inset-0 bg-gradient-to-t from-[#070709] via-transparent to-[#070709]/80" />
        </div>

        {/* Top Spacer for floating glass nav */}
        <div className="h-24" />

        {/* Central Cinematic Hero Composition */}
        <div className="relative z-10 max-w-5xl mx-auto px-6 text-center flex flex-col items-center justify-center my-auto">
          {/* Royal Eyebrow Badge */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.15 }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-[rgba(218,179,106,0.3)] bg-[rgba(255,255,255,0.04)] backdrop-blur-md mb-6"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#c5a059]" />
            <span className="text-[10px] sm:text-[11px] font-sans font-medium tracking-[0.3em] text-[#c5a059] uppercase">
              ESTABLISHED IN RAJENDRA PLACE • NEW DELHI
            </span>
          </motion.div>

          {/* Main Display Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.25 }}
            className="font-display text-4xl sm:text-6xl md:text-7xl lg:text-8xl tracking-[0.16em] text-[#fbf8f2] uppercase leading-[1.05]"
          >
            Mughal Mahal
          </motion.h1>

          {/* Hindi Script Subheading */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.9 }}
            transition={{ duration: 0.9, delay: 0.4 }}
            className="font-hindi text-xl sm:text-2xl md:text-3xl text-[#c5a059] tracking-wider mt-2 mb-4"
          >
            मुगल महल रेस्टोरेंट
          </motion.div>

          {/* Supporting Statement - Strictly factual */}
          <motion.p
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.5 }}
            className="max-w-2xl text-xs sm:text-sm md:text-base text-[#cfc8bc] font-serif leading-relaxed px-4 mb-8"
          >
            Authentic Mughlai & North Indian dining in Rajendra Place, New Delhi.
            Renowned for iconic Murg Makhani, charcoal tandoori specialties, and timeless royal recipes.
          </motion.p>

          {/* Primary and Secondary CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.65 }}
            className="flex flex-col sm:flex-row items-center gap-4 w-full sm:w-auto"
          >
            <button
              id="hero-reserve-btn"
              onClick={onOpenReservation}
              className="w-full sm:w-auto bg-[#c5a059] hover:bg-[#d8b46a] text-[#0a0a0c] font-sans font-semibold text-xs tracking-[0.22em] uppercase py-3.5 px-8 rounded transition-all duration-300 shadow-[0_10px_30px_-5px_rgba(197,160,89,0.3)] flex items-center justify-center gap-2 hover:scale-[1.02]"
            >
              <Calendar className="w-4 h-4" />
              RESERVE A TABLE
            </button>

            <button
              id="hero-menu-btn"
              onClick={() => {
                navigate('/menu');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="w-full sm:w-auto border border-[rgba(255,255,255,0.25)] hover:border-[#c5a059] bg-[rgba(255,255,255,0.04)] hover:bg-[rgba(197,160,89,0.12)] text-[#f4efe6] hover:text-[#c5a059] font-sans font-medium text-xs tracking-[0.22em] uppercase py-3.5 px-8 rounded backdrop-blur-md transition-all duration-300 flex items-center justify-center gap-2"
            >
              <Utensils className="w-4 h-4" />
              EXPLORE THE CUISINE
            </button>
          </motion.div>
        </div>

        {/* Scroll Indicator & Verified Summary Microbar */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.85 }}
          className="relative z-10 w-full border-t border-[rgba(218,179,106,0.18)] bg-[rgba(10,10,14,0.7)] backdrop-blur-xl py-3.5"
        >
          <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-4 sm:gap-8 text-[11px] font-sans tracking-wider text-[#9f988b] uppercase">
              <span>Rajendra Place, New Delhi</span>
              <span className="hidden sm:inline">•</span>
              <span>11:30 AM – 11:30 PM</span>
              <span className="hidden sm:inline">•</span>
              <span className="text-[#c5a059]">3.9 ★ (1,142+ Google Reviews)</span>
            </div>

            {/* Scroll down prompt */}
            <button
              onClick={scrollToContent}
              className="flex items-center gap-1.5 text-[10px] font-sans tracking-[0.2em] text-[#c5a059] uppercase hover:text-[#f4efe6] transition-colors focus:outline-none"
            >
              <span>Scroll Down</span>
              <ChevronDown className="w-3.5 h-3.5 animate-bounce" />
            </button>
          </div>
        </motion.div>
      </section>

      {/* ====================================================
          2. SIGNATURE DISH / CULINARY STORY
      ==================================================== */}
      <section id="culinary-story" className="py-20 md:py-28 bg-[#0a0a0d] relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-[10px] font-sans tracking-[0.3em] text-[#c5a059] uppercase block mb-2 font-semibold">
              The Living Legacy
            </span>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl text-[#f4efe6] tracking-tight uppercase">
              Culinary Craftsmanship
            </h2>
            <div className="font-hindi text-sm text-[#8e8779] mt-1">
              धीमी आंच और परंपरागत मसाले
            </div>
          </div>

          <SignatureDishStory
            onExploreMenu={() => {
              navigate('/menu');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onOpenOrder={onOpenOrder}
          />
        </div>
      </section>

      {/* ====================================================
          3. RESTAURANT EXPERIENCE (SHORT & CINEMATIC)
      ==================================================== */}
      <section id="restaurant-experience" className="py-16 md:py-24 bg-[#08080b] border-t border-[rgba(255,255,255,0.04)]">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <RestaurantExperienceStory
            onExploreAbout={() => {
              navigate('/about');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        </div>
      </section>

      {/* ====================================================
          4. 3–4 SIGNATURE HIGHLIGHTS
      ==================================================== */}
      <section id="signature-highlights" className="py-20 md:py-28 bg-[#0a0a0d] border-t border-[rgba(255,255,255,0.04)]">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <span className="text-[10px] font-sans tracking-[0.3em] text-[#c5a059] uppercase block mb-2 font-semibold">
              The Pillar Pillars of Taste
            </span>
            <h2 className="font-display text-3xl sm:text-4xl md:text-5xl text-[#f4efe6] tracking-tight uppercase">
              Royal Dining Pillars
            </h2>
            <div className="font-hindi text-sm text-[#8e8779] mt-1">
              हमारी खासियत • मुगलई एवं उत्तर भारतीय परंपरा
            </div>
          </div>

          <SignatureHighlights />
        </div>
      </section>

      {/* ====================================================
          5. COMPACT RESERVATION CTA
      ==================================================== */}
      <section id="reservation-cta-section" className="py-20 md:py-28 bg-[#070709] border-t border-[rgba(255,255,255,0.04)]">
        <div className="max-w-7xl mx-auto px-6 md:px-8">
          <CompactReservationCTA onOpenReservation={onOpenReservation} />
        </div>
      </section>
    </div>
  );
};
